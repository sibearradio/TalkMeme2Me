from pymongo import MongoClient
import image_scraper
import os
import urllib
import gridfs
import bson
import traceback
import base64
from twilio.rest import Client




# pprint library is used to make the output look more pretty
from pprint import pprint
import bs4
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
from flask import Flask, request, redirect
from twilio.twiml.messaging_response import MessagingResponse
app = Flash(__name__)
account_sid = "ACa742e26aac70bdb3d640b0ad8ce2f7fc"
account_tocken = "94fa41be0ad7cf7a2eb55e25fe662030"
client = Client(accound_sid, auth_token)


# connect to MongoDB, change the << MONGODB URL >> to reflect your own connection string

#
client = MongoClient("mongodb://danklords:hackny2017@dankmemebank-shard-00-00-tbdbz.mongodb.net:27017,dankmemebank-shard-00-01-tbdbz.mongodb.net:27017,dankmemebank-shard-00-02-tbdbz.mongodb.net:27017/admin?replicaSet=DankMemeBank-shard-0&ssl=true")
db=client.DankBank
# Issue the serverStatus command and print the results

@app.route("/sms", methods=['GET','POST'])
def sms_reply():
	resp=MessagingResponse()
	resp.message("hello world")


	return str(response)



if "__name__" == "__main__":
	app.run

